export interface VoiceOption {
  id: string;
  name: string;
  description?: string;
}
